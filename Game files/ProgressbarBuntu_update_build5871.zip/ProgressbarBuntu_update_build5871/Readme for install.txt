Hello and thank you for downloading this mod this is the first one to be able to be used as you like at the moment there are still a lot of files to be replaced and modified !

/!\This mod is still under development and therefore some elements are missing mentioned a second ago./!\

How to Install ?

Requirement:

-A computer 
-Progressbar95 

[Before you start you touch directly to the internal file why? Because the file "ressource.car" present in the game is not touchable and therefore the affiliate files in this file must be the same for example:

To make it short and easy the names of the images, etc..are written in the rsc.car file and programmed so that it works so if you want to put "Image of my cat" it doesn't work it will audra put "wallpaper1" unless icoeye (The developer of the game changes the names

In short, if you delete an image needed for the game you will be penalized that's why I created a backup folder if one day you do something wrong.]

1) It's simple! Let's take "gui.png" there is one in your game folder? (Art > Skins > 1X) and another one in the mod folder, so move the game one to another folder to store it and then put the world one to avoid replacing it ! 

2)Enjoy ! 

ModBeta_Build5871


